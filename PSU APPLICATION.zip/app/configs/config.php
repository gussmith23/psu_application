<?php

/**
 * Path used to server ember template
 */
$app->config(array(
    'templates.path' => '../app/templates/'
));